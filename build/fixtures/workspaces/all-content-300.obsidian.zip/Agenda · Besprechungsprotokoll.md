---
language: en
tags:
- Performance
---

**\[Referenz\]**

{{workspace.name}} · {{date\_long}}

| **Workspace** | {{workspace.name}} | **Datum** | {{date\_long}} |
| --- | --- | --- | --- |
| **Zeit / Ort** | \[Zeit\] · \[Ort\] | **Protokoll** | {{creator.name}} · {{creator.email}} |
| **Anlass** | \[Anlass\] | **Erstellt** | {{document.created\_at.datetime}} |
| **Referenz** | Agenda 01–06 | **Moderation** | \[Moderation\] |

**Anwesenheit**

- [ ] {{member.name}} · {{member.email}}

## 01 · \[Agendapunkt\]

| **Typ** | **Festgehalten** | **Ergebnis / nächster Schritt** |
| --- | --- | --- |
| Information | **01** · \[Thema\] — \[Ergebnis / Begründung\] | **\[Stand\]** |
| Entscheidung | **02** · \[Thema\] — \[Ergebnis / Begründung\] | **\[Stand\]** — \[Verantwortlich\] · \[Zieldatum\] |

## 02 · \[Agendapunkt\]

| **Typ** | **Festgehalten** | **Ergebnis / nächster Schritt** |
| --- | --- | --- |
| Diskussion | **03** · \[Thema\] — \[Ergebnis / Begründung\] | **\[Stand\]** — \[Verantwortlich\] · \[Zieldatum\] |
| Maßnahme | **04** · \[Thema\] — \[Ergebnis / Begründung\] | **\[Stand\]** — \[Verantwortlich\] · \[Zieldatum\] |

## 03 · \[Agendapunkt\]

| **Typ** | **Festgehalten** | **Ergebnis / nächster Schritt** |
| --- | --- | --- |
| Offene Frage | **05** · \[Thema\] — \[Ergebnis / Begründung\] | **\[Stand\]** — \[Verantwortlich\] · \[Zieldatum\] |
| Risiko | **06** · \[Thema\] — \[Ergebnis / Begründung\] | **\[Stand\]** — \[Verantwortlich\] · \[Zieldatum\] |

**Nächste Besprechung** · \[Datum und Uhrzeit\]

**Nachbereitung** · \[Unterlagen, Aufgaben und offene Rückmeldungen\]