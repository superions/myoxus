---
language: en
tags:
- Performance
---

**\[Referenz\]**

\[Besprechungstitel\]

| **Workspace** | {{workspace.name}} | **Datum** | {{date\_long}} |
| --- | --- | --- | --- |
| **Zeit / Ort** | \[Zeit\] · \[Ort\] | **Moderation** | \[Moderation\] |
| **Protokoll** | {{creator.name}} | **E-Mail** | {{creator.email}} |
| **Erstellt** | {{document.created\_at.datetime}} |  |  |

**Ziel** · \[Ziel\]

**Anwesenheit**

- [ ] {{member.name}} · {{member.email}}

## Punkte & Ergebnisse

| **Nr.** | **Typ** | **Thema & Ergebnis** | **Verantwortlich / Termin** | **Stand** |
| --- | --- | --- | --- | --- |
| 01 | Information | \[Thema\] — \[Ergebnis / Begründung\] | \[Verantwortlich\] · \[Zieldatum\] | \[Stand\] |
| 02 | Entscheidung | \[Thema\] — \[Ergebnis / Begründung\] | \[Verantwortlich\] · \[Zieldatum\] | \[Stand\] |
| 03 | Diskussion | \[Thema\] — \[Ergebnis / Begründung\] | \[Verantwortlich\] · \[Zieldatum\] | \[Stand\] |
| 04 | Maßnahme | \[Thema\] — \[Ergebnis / Begründung\] | \[Verantwortlich\] · \[Zieldatum\] | \[Stand\] |
| 05 | Offene Frage | \[Thema\] — \[Ergebnis / Begründung\] | \[Verantwortlich\] · \[Zieldatum\] | \[Stand\] |
| 06 | Risiko | \[Thema\] — \[Ergebnis / Begründung\] | \[Verantwortlich\] · \[Zieldatum\] | \[Stand\] |

**Nächste Besprechung** · \[Datum und Uhrzeit\]

**Nachbereitung** · \[Unterlagen, Aufgaben und offene Rückmeldungen\]