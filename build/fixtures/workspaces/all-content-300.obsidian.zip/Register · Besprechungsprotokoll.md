---
language: en
tags:
- Performance
---

**\[Referenz\]**

{{workspace.name}} · {{date\_long}}

| **Workspace** | {{workspace.name}} | **Datum** | {{date\_long}} |
| --- | --- | --- | --- |
| **Zeit / Ort** | \[Zeit\] · \[Ort\] | **Protokoll** | {{creator.name}} · {{creator.email}} |
| **Anlass** | \[Anlass\] | **Erstellt** | {{document.created\_at.datetime}} |
| **Referenz** | Register 01–06 | **Moderation** | \[Moderation\] |

**Anwesenheit**

- [ ] {{member.name}} · {{member.email}}

## Protokollregister

| **Nr. / Thema** | **Typ** | **Ergebnis / Begründung** | **Verantwortlich** | **Termin** | **Stand** |
| --- | --- | --- | --- | --- | --- |
| 01 · \[Thema\] | Information | \[Ergebnis / Begründung\] | \[Verantwortlich\] | \[Zieldatum\] | \[Stand\] |
| 02 · \[Thema\] | Entscheidung | \[Ergebnis / Begründung\] | \[Verantwortlich\] | \[Zieldatum\] | \[Stand\] |
| 03 · \[Thema\] | Diskussion | \[Ergebnis / Begründung\] | \[Verantwortlich\] | \[Zieldatum\] | \[Stand\] |
| 04 · \[Thema\] | Maßnahme | \[Ergebnis / Begründung\] | \[Verantwortlich\] | \[Zieldatum\] | \[Stand\] |
| 05 · \[Thema\] | Offene Frage | \[Ergebnis / Begründung\] | \[Verantwortlich\] | \[Zieldatum\] | \[Stand\] |
| 06 · \[Thema\] | Risiko | \[Ergebnis / Begründung\] | \[Verantwortlich\] | \[Zieldatum\] | \[Stand\] |

**Nächste Besprechung** · \[Datum und Uhrzeit\]

**Nachbereitung** · \[Unterlagen, Aufgaben und offene Rückmeldungen\]